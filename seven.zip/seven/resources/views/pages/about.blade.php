@extends('layouts.master')
@section('content')

        <!-- About Content -->
        <div id="content" class="site-content">

            <div class="page-header-image relative">
                <img src="custom/demo-images/me.jpg" alt="About">
            </div>


            <article>
                <div class="content-1070 center-relative entry-content">
                    <div class="content-900 center-relative">
                        <h1 class="entry-title">About Me</h1>
                        <div class="one_half ">
                            <p>We choose to go to the moon in this decade and do the other things, not because they are easy.</p>
                            <br>
                            <p>Because they are hard, because that goal will serve to organize and measure the best of our energies and skills, because that challenge is one that we are willing to accept, one we are unwilling to postpone and one.</p>
                        </div>
                        <div class="one_half last">
                            Never in all their history have men been able truly to conceive of the world as one: a single sphere, a globe, having the qualities of a globe, a round earth in which all the directions eventually meet, in which there is no center because every point, or none, is center an equal earth which all men occupy as equals. The airman’s earth, if free men make it, will be truly round.<br>
                        </div>
                        <div class="clear"></div>
                        
                    </div>
                    
                </div>
            </article>
        </div>
@endsection
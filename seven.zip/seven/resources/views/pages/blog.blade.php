@extends('layouts.master')
@section('content')

        <!-- Blog Content -->
        <div id="content" class="site-content">
            <div class="full-screen-scroll">
                <ul id="cbp-bislideshow" class="cbp-bislideshow scroll">
                @foreach ($blogs as $blog)
                    <li style="background-image: url('demo-images/02.jpg');">
                        <article class="entry-holder">
                            <h2 class="entry-title">
                                <a href="single.html">{{ $blog['title'] }}</a>
                            </h2>
                            <div class="info-holder">
                                <div class="cat-links">
                                    <ul>
                                        <li>
                                            <a href="#">{{ $blog['tag'] }} </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="entry-date published">{{ date('M j, Y', strtotime( $blog['updated_at'])) }}</div>
                            </div>
                            <div class="excerpt"> {{substr(strip_tags($blog['body']),0,200)}} {{ strlen(strip_tags($blog['body'] )) > 200 ? "..." : "" }}<a class="read-more" href="single/{{$blog->id}}"></a></div>
                            <div class="clear"></div> 
                          
                        </article>
                    </li>
                  @endforeach
                    
                </ul>
            
            </div> {!! $blogs->links(); !!}
            <div class="clear"></div>

        </div>
@endsection

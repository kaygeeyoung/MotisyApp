@extends('layouts.master')
@section('content')

        <!-- Single Content -->
        <div id="content" class="site-content center-relative">
            <div class="single-post-wrapper content-1070 center-relative">

                <article class="center-relative">
                    <h1 class="entry-title">
                     {{ $blogs['title'] }}
                    </h1>
                    <div class="post-info content-660 center-relative">
                        <div class="cat-links">
                            <ul>
                                <li><a href="#"> {{ $blogs['tag'] }} </a></li>
                            </ul>
                        </div>
                        <div class="entry-date published">{{ date('M j, Y', strtotime( $blogs['updated_at'])) }}</div>
                        <div class="clear"></div>
                    </div>

                    <div class="entry-content">
                        <div class="content-wrap content-660 center-relative">
                            <p> {{ $blogs['body'] }}</p>                           
                            </div>                                         
                    </div>                  
                </article>
            </div>
        </div>
@endsection

@extends('layouts.custom')

@section('content')


              
@if (Auth::guard('web')->check()) 
                <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit Profile</h4>
                            </div>
                            <div class="content">
                                {!! Form::model($user,['route' => ['profileupdate'], 'method' => 'PUT', 'files' => true]) !!}
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                
                                    {{ Form::label('name', 'First Name') }}
                                    {{ Form::text('name', $user->name, array('class' => 'form-control','required'=>'','minlength'=>'3')) }}
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                
                                                {{ Form::label('lastname', 'Last Name') }}
                                    {{ Form::text('lastname', $user->lastname, array('class' => 'form-control','required'=>'','minlength'=>'3')) }}
                                    
                                            </div>
                                        </div>
                                                                                
                                    </div>
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address</label>
                                                <input type="email" class="form-control" disabled="" placeholder="Email" value="{{ $user->email }}">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                
                                                                                {{ Form::label('aboutme', 'About Me') }}
                                    {{ Form::textarea('aboutme', $user->aboutme, array('class' => 'form-control','required'=>'','minlength'=>'3', 'placeholder'=>'Write something about yourself')) }}
                                    
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-6">
                                            <div class="form-group">
                                                
                                                {{ Form::label('password', 'Password') }}
                                    {{ Form::password('password', array('class' => 'form-control')) }}
                                    
                                            </div>
                                        </div>
                                    </div>
                                
                                    <div class="row">
                                      <div class="col-md-6">
                                            <div class="form-group">
                                    {{ Form::label('image', 'Profile Picture)') }}
                                    {{ Form::file('image',array('class' => 'form-control')) }}
                                            </div>
                                        </div>
                                    </div>
                                
                                
                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update Profile</button>
                                    <div class="clearfix"></div>
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                            </div>
                            <div class="content">
                                <div class="author">
                                     <a href="#">
                                         
                                    <img class="avatar border-gray" src="{{asset('profileimages/' . $user->profile_picture)}}" alt="..."/>

                                      <h4 class="title">{{ Auth::user()->name }}<br />
                                         <small>{{ Auth::user()->lastname }}</small>
                                      </h4>
                                    </a>
                                </div>
                                <p class="description text-center"> 
                                {{ Auth::user()->aboutme }}
                                </p>
                            </div>
                         
                        </div>
                    </div>
                    
                    
                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                            </div>
                            <div class="content">
                                <div class="author">
                                     
                                </div>
                                <p class="description text-center"> 
                                Public Profile Status : &nbsp;
                                
                                @if ($user->public_profile == 1)
                                Enabled
                                @else
                                Disabled
                                @endif
                        
                                     <form action="{{route('publicstatus')}}" method="POST" id="deliver-toggle">
                                              {{csrf_field()}}
                                           
                                    <select name="public_profile" class="btn btn-default btn-block">
                                      <option value="0">Disable</option>
                                      <option value="1">Enable</option>
                                    </select>
                                    <br>
                                    <button class="btn btn-info btn-fill" onclick="submit">Change Status</button>
                                        
                                            </form>     
                                </p>
                            </div>
                         
                        </div>
                    </div>
                    

                </div>
            </div>
     @endif
        
@endsection

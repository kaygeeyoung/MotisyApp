@extends('layouts.admincustom')

@section('content')
                 @if(Session::has('flash_message'))
                        <div class="alert alert-success">
                            {{ Session::get('flash_message') }}
                        </div>
                    @endif
            {!! Form::open(['route' => 'adminaddpoststore', 'method' => 'POST', 'files' => true, 'data-parsley-validate'=>'', 'class'=>'col-md-12 card' ]) !!}
        <br>
        <h4 class="title">&nbsp; Add New Post </h4>
        <br>  
            <div class="row">
                <div class="form-group">
                    <div class="col-md-6">
                    {{ Form::label('title', 'Post Title') }}
                    {{ Form::text('title', null, array('class' => 'form-control','required'=>'','minlength'=>'5')) }}
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="form-group">
                    <div class="col-md-6">
                    
                     {{ Form::label('category', 'Post Category') }}
                     <select class="form-control" name="category">
                         @foreach($categories as $category)
                         <option value="{{$category->name}}">{{$category->name}}</option>
                         @endforeach
                     </select>
 
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="form-group">
                    <div class="col-md-6">
                    
                     {{ Form::label('tag', 'Post tag') }}
                     <select class="form-control" name="tag">
                         @foreach($tags as $tag)
                         <option value="{{$tag->name}}">{{$tag->name}}</option>
                         @endforeach
                     </select>
 
                    </div>
                </div>
            </div>
        
            <div class="row">
                <div class="form-group">
                    <div class="col-md-12">
                    {{ Form::label('body', 'Body') }}
                    {{ Form::textarea('body', null, array('class' => 'form-control')) }}
                    </div>
                </div>
            </div>          
            
            <div class="row">
                <div class="form-group">
                    <div class="col-md-6">
                    {{ Form::label('image', 'Image') }}
                    {{ Form::file('image',array('class' => 'form-control')) }}
                    </div>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="form-group">
                     <div class="col-md-4">
                        {{ Form::submit('Add New Post', array('class' => 'btn btn-info btn-fill')) }}
                     </div>
                </div>
            </div>
            <br>
            <div class="clearfix"></div>
            {!! Form::close() !!}
                    
                
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@extends('layouts.admincustom')

@section('content')


  
                      
            {!! Form::model($editpost,['route' => ['admineditpostsave',$editpost->id], 'method' => 'PUT', 'files' => true, 'class'=>'col-md-12 card']) !!}
           
            <br>
            <h4 class="title">&nbsp; Edit Post </h4>
            <br>             
            
            <div class="row">
                <div class="form-group">
                    <div class="col-md-6">
                    {{ Form::label('title', 'Post Title') }}
                    {{ Form::text('title', $editpost->title, array('class' => 'form-control','required'=>'','minlength'=>'5')) }}
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="form-group">
                    <div class="col-md-6">
                    {{ Form::label('category', 'Category') }}
                    <select class="form-control" name="category">
                    @foreach($categories as $category)
                    <option value="{{$category->name}}">{{$category->name}}
                    </option>
                     @endforeach
                    </select>
                  </div>
                </div>
            </div>
            
            <div class="row">
                <div class="form-group">
                    <div class="col-md-6">
                    {{ Form::label('tag', 'Tag') }}
                    <select class="form-control" name="tag">
                    @foreach($tags as $tag)
                    <option value="{{$tag->name}}">{{$tag->name}}
                    </option>
                     @endforeach
                    </select>
                  </div>
                </div>
            </div>
            
            <div class="row">
                <div class="form-group">
                    <div class="col-md-12">
                    {{ Form::label('body', 'Body') }}
                    {{ Form::textarea('body', $editpost->body, array('class' => 'form-control')) }}
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="form-group">
                    <div class="col-md-12">
                    {{ Form::label('image', 'Image') }}
                    {{ Form::file('image',array('class' => 'form-control')) }}
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="form-group">
                     <div class="col-md-4">
                        {{ Form::submit('Update Post', array('class' => 'btn btn-info btn-fill')) }}
                     </div>
                </div>
            </div>
            <br>
            <div class="clearfix"></div>
            {!! Form::close() !!}
            
                
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@extends('layouts.admincustom')

@section('content')

                    
                  @if(Session::has('flash_message'))
                        <div class="alert alert-success">
                            {{ Session::get('flash_message') }}
                        </div>
                    @endif
				<div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Users</h4>

                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>ID</th>
                                    	<th>Name</th>
                                    	<th>Email</th>
                                    	<th>Author Status</th>
                                    	<th>Action</th>
                                    </thead>
                                    
                                    <tbody>
                                        
                                	@foreach($allUsers as $usr)
                                        <tr>
                                        	<td>{{ $usr->id }}</td>
                                			<td>{{ $usr->name }}</td>
                                			<td>{{ $usr->email }}</td>
                                			
                                			@if ($usr->status == 1)
                                			<td>Active</td>
                                	        @else
                                	       <td>Not Active</td>
                                	        @endif
                                	       
	                                       
                    	                   <form action="{{route('update.status',$usr->id)}}" method="POST" class="pull-right" id="deliver-toggle">
                                              {{csrf_field()}}
                                            <td>        
                                            <input type="checkbox" value="1" name="status_id"  {{$usr->status==1?"checked":"" }}>
                                            <input type="submit" value="Submit">
                                            </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
             
@endsection

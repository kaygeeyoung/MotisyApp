@extends('layouts.admincustom')

@section('content')
                      
                      
      <div class="col-md-12">
        <div class="card card-user">
            <div class="image">
                
            </div>
            <div class="content">
               <div class="author">
                     <a href="#">
                    <img class="border-gray" src="{{ asset('images/' . $vpost->image) }}"  height="190" width="120" alt="..."/>

                      <h4 class="title">{{ $vpost->title }}<br />
                         <small>{{ $vpost->updated_at }}</small>
                      </h4>
                    </a>
                </div>
                <p class="description text-center"> {{ $vpost->category }}
                </p>
                
                <p class="description text-center"> {{ $vpost->tag }}
                </p>
                
                <p class="description text-center"> {{ $vpost->body }}
                </p>
                
                <p class="description text-center">{{ HTML::linkRoute('admineditpost','Edit', array($vpost->id)) }}
                
                
                    {!! Form::open(['url' => 'admin/adminpost/delete', 'class'=>'description text-center']) !!}
                    {!! Form::hidden('id', $vpost->id) !!}
                    {!! Form::submit('Delete', ['class' => 'btn btn-info btn-fill']) !!}
                    {!! Form::close() !!}   
                </p>

            </div>
        
        </div>
    </div>

                    <br>
                    
                
                 
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@extends('layouts.admincustom')

@section('content')

                    
                  @if(Session::has('flash_message'))
                        <div class="alert alert-success">
                            {{ Session::get('flash_message') }}
                        </div>
                    @endif
				<div class="col-md-12">
                        <div class="card">
                            <br>
                            <h4 class="title">&nbsp;
            <a href="{{ URL::route('adminaddpost') }}" class="btn btn-info btn-fill"> Add New Post </a>
            </h4>
            
                            <div class="header">
                                <h4 class="title">Posts</h4>

                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        
                                    	<th>Post Title</th>
                                    	<th>Post by</th>
                                    	<th>Date Created</th>
                                    	<th>Date updated</th>
                                    </thead>
                                    
                                    <tbody>
                                        
                                	@foreach($allPosts as $post)
                                        <tr>
                                        	<td>{{HTML::linkRoute('adminviewpost',$post->title, array($post->id)) }}</td>
                                		
                                		<td>{{ $post->name }}</td>
                                			
                          
                                		<td>{{ $post->created_at }}</td>
                                	        
                                	       <td>{{ $post->updated_at }}</td>
                                	        
                                	       
	                                       
                    	         
                                           
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
             
@endsection

<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <title>Kagiso Ntwampe</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="description" content="Kagiso Mpho Ntwampe" />
        <meta name="keywords" content="Kagiso Mpho Ntwampe" />
        <meta name="author" content="Kagiso" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

       
        <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CLibre+Baskerville:400,400italic,700' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" type="text/css"  href='custom/css/clear.css' />
        <link rel="stylesheet" type="text/css"  href='custom/css/common.css' />
        <link rel="stylesheet" type="text/css"  href='custom/css/font-awesome.min.css' />
        <link rel="stylesheet" type="text/css"  href='custom/css/carouFredSel.css' />
        <link rel="stylesheet" type="text/css"  href='custom/css/sm-clean.css' />
        <link rel="stylesheet" type="text/css"  href='custom/style.css' />

    </head>


    <body class="home blog">

        <!-- Preloader Gif -->
        <table class="doc-loader">
            <tbody>
                <tr>
                    <td>
                        <img src="custom/images/ajax-document-loader.gif" alt="Loading...">
                    </td>
                </tr>
            </tbody>
        </table>

        <!-- Left Sidebar -->
        <div id="sidebar" class="sidebar">
            <div class="menu-left-part">
                <div class="search-holder">
                    <label>
                        <input type="search" class="search-field" placeholder="Type here to search..." value="" name="s" title="Search for:">
                    </label>
                </div>
                <div class="site-info-holder">
                    <h1 class="site-title">Kagiso Ntwampe</h1>
                   
                </div>
                <nav id="header-main-menu">
                    <ul class="main-menu sm sm-clean">
                        <li><a href="/">Home</a></li>
                        <!-- <li><a href="about">About</a></li> -->
                        <li><a href="blog">Blog</a></li>
                        <li><a href="contact">Contact</a></li>
                    </ul>
                </nav>
                <footer>
                    <div class="footer-info">
                        © 2018 Kagiso Ntwampe<br> Designed <i class="fa fa-heart"></i> by <a href="https://seventecgroup.co.za">Seven Tec Group</a>
                    </div>
                </footer>
            </div>
            <div class="menu-right-part">
                <div class="logo-holder">
                    <a href="">
                        <img src="custom/images/logo.png" alt="Kagiso Ntwampe">
                    </a>
                </div>
                <div class="toggle-holder">
                    <div id="toggle">
                        <div class="menu-line"></div>
                    </div>
                </div>
                <div class="social-holder">
                    <div class="social-list">
                        <a href="https://www.twitter.com/badwarsa"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.youtube.com/badwarsa"><i class="fa fa-youtube-play"></i></a>
                        <a href="https://www.facebook.com/mpho.badwar"><i class="fa fa-facebook"></i></a> 
                    </div>
                </div>
                <div class="fixed scroll-top"><i class="fa fa-caret-square-o-up" aria-hidden="true"></i></div>
            </div>
            <div class="clear"></div>
        </div>

@yield('content')



<!--Load JavaScript-->
        <script type="text/javascript" src="custom/js/jquery.js"></script>
        <script type='text/javascript' src='custom/js/imagesloaded.pkgd.js'></script>
        <script type='text/javascript' src='custom/js/jquery.nicescroll.min.js'></script>
        <script type='text/javascript' src='custom/js/jquery.smartmenus.min.js'></script>
        <script type='text/javascript' src='custom/js/jquery.carouFredSel-6.0.0-packed.js'></script>
        <script type='text/javascript' src='custom/js/jquery.mousewheel.min.js'></script>
        <script type='text/javascript' src='custom/js/jquery.touchSwipe.min.js'></script>
        <script type='text/javascript' src='custom/js/jquery.easing.1.3.js'></script>
        <script type='text/javascript' src='custom/js/main.js'></script>
    </body>
</html>






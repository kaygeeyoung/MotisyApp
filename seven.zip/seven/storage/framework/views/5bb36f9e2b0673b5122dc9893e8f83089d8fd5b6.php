<?php $__env->startSection('content'); ?>

        <!-- Single Content -->
        <div id="content" class="site-content center-relative">
            <div class="single-post-wrapper content-1070 center-relative">

                <article class="center-relative">
                    <h1 class="entry-title">
                     <?php echo e($blogs['title']); ?>

                    </h1>
                    <div class="post-info content-660 center-relative">
                        <div class="cat-links">
                            <ul>
                                <li><a href="#"> <?php echo e($blogs['tag']); ?> </a></li>
                            </ul>
                        </div>
                        <div class="entry-date published"><?php echo e(date('M j, Y', strtotime( $blogs['updated_at']))); ?></div>
                        <div class="clear"></div>
                    </div>

                    <div class="entry-content">
                        <div class="content-wrap content-660 center-relative">
                            <p> <?php echo e($blogs['body']); ?></p>                           
                            </div>                                         
                    </div>                  
                </article>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
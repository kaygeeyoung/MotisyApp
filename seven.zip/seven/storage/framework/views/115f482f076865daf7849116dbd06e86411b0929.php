<?php $__env->startSection('content'); ?>
        <!-- Home Content -->
        <div id="content" class="site-content">
            <div id="blog-wrapper">
                <div class="blog-holder center-relative">


                    <article id="post-1" class="blog-item-holder featured-post">
                        <div class="entry-content relative">
                            <div class="content-1170 center-relative">
                                <div class="cat-links">
                                    <ul>
                                        <li>
                                            <a href="#"><?php echo e($blogs['tag']); ?> </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="entry-date published"> <?php echo e(date('M j, Y', strtotime( $blogs['updated_at']))); ?> </div>
                                <h2 class="entry-title">
                                    <a href="single.html"> <?php echo e($blogs['title']); ?></a>
                                </h2>
                                <div class="excerpt">
                                  <?php echo e(substr(strip_tags($blogs['body']),0,300)); ?> <?php echo e(strlen(strip_tags($blogs['body'] )) > 300 ? "..." : ""); ?>  <a href="single/<?php echo e($blogs->id); ?>" class="read-more"></a>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </article>

                </div>
                <div class="clear"></div>
                <div class="block load-more-holder"><a href="blog">SEE MORE BLOGS</a></div>
            </div>

            <div class="featured-image-holder">
                <div class="featured-post-image" style="background-image: url(custom/demo-images/me.jpg)"></div>

            </div>
            <div class="clear"></div>
        </div>

<?php $__env->stopSection(); ?>

        

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
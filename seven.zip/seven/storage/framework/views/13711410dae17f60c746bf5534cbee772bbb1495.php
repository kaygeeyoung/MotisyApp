<?php $__env->startSection('content'); ?>
        <!-- Contact Content -->
        <div id="content" class="site-content">


            <article>
                <div class="content-1070 center-relative entry-content">
                    <div class="content-900 center-relative">
                        <h1 class="entry-title">Contact</h1>
                        <div class="one_half ">
                         
                            <div class="montserrat">
                                <span style="color: #adadad;">Address:</span>&nbsp;Pretoria, Gauteng, South Africa<br>  
                                <span style="color: #adadad;"> E-mail:</span> info@kagisontwampe.co.za<br
                                <span style="color: #adadad;">Phone:</span> +27 61-321-9544<br>
                                <span style="color: #adadad;">Hours:</span> 8:00 am – 5:00 pm
                            </div>
                        </div>
                        <div class="one_half last ">
                            <div class="contact-form">
                                <p><input id="name" type="text" name="name" placeholder="Name"></p>
                                <p><input id="contact-email" type="email" name="email" placeholder="Email"></p>
                                
                                <p><textarea id="message" name="message" placeholder="Message"></textarea></p>
                                <p><input type="submit" onClick="" value="SEND"></p>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
            </article>


        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

        <!-- Blog Content -->
        <div id="content" class="site-content">
            <div class="full-screen-scroll">
                <ul id="cbp-bislideshow" class="cbp-bislideshow scroll">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="background-image: url('demo-images/02.jpg');">
                        <article class="entry-holder">
                            <h2 class="entry-title">
                                <a href="single.html"><?php echo e($blog['title']); ?></a>
                            </h2>
                            <div class="info-holder">
                                <div class="cat-links">
                                    <ul>
                                        <li>
                                            <a href="#"><?php echo e($blog['tag']); ?> </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="entry-date published"><?php echo e(date('M j, Y', strtotime( $blog['updated_at']))); ?></div>
                            </div>
                            <div class="excerpt"> <?php echo e(substr(strip_tags($blog['body']),0,200)); ?> <?php echo e(strlen(strip_tags($blog['body'] )) > 200 ? "..." : ""); ?><a class="read-more" href="single/<?php echo e($blog->id); ?>"></a></div>
                            <div class="clear"></div> 
                          
                        </article>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </ul>
            
            </div> <?php echo $blogs->links();; ?>

            <div class="clear"></div>

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
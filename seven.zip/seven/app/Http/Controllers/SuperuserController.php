<?php

namespace App\Http\Controllers;

use App\User;
use View;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Flash;
use Image;

class SuperuserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:web');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function profile(Request $request)
    {
        $user=Auth::User();
        
	return View::make("superuser/profile")->with('user', $user);
       
    }
    public function profileupdate(Request $request){
        $user = Auth::user();
        

        $user['name'] = $request->input('name');
        $user['lastname'] = $request->input('lastname');
        $user['aboutme'] = $request->input('aboutme');
            
        if ( ! $request->input('password') == '')
        {
           $user->password = bcrypt($request->input('password'));
        }
        
        
        
        if($request->file('image')) {
            $file = $request->file('image');
                
            //$file_name=$file->getClientOriginalName();        
            //$file_name = time() . '.' . $file->getClientOriginalExtension();
           
            $image=$request->image;
                if($file){
                    $current_time = Carbon::now()->toDateTimeString();
                    $imageName=$image->getClientOriginalName();
                    //$imageName=$image->Carbon::now()->toDateTimeString().'.'.getClientOriginalExtension();
                    $image->move('profileimages',$imageName);
                }
                
            $user['profile_picture'] = $imageName;
        }

           
       
        
        $user->save();
    
        flash('Your profile has been updated!');
        return redirect()->route('profile');
    }
    
    public function publicstatus(Request $request){
        $user = Auth::user();
        $user->public_profile=$request->public_profile;
        $user->update();
        return redirect()->route('profile');
    
    }

}

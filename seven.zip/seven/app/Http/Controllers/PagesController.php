<?php

namespace SevenTecGroup\Http\Controllers;

use Illuminate\Http\Request;
use SevenTecGroup\Blog;

class PagesController extends Controller
{
    public function index()
    { 
         
        $blog = Blog:: orderBy('id', 'desc')->first();
        return view('pages.welcome')->withBlogs($blog);
    }

    public function blog()
    {
        $blog = Blog:: orderBy('id', 'desc')->SimplePaginate(5);
        return view('pages.blog')->withBlogs($blog);
    }

    public function single(Request $request, $id)
    {
        $blog = Blog::find($id);
        return view('pages.single')->withBlogs($blog);
    }
    
    public function about()
    {
        return view('pages.about');
    }

    public function contact()
    {
        return view('pages.contact');
    } 

    public function contact_action()
    {
         $this->validate($request, [
            'email' => 'required|email',
            'name' => 'min:3',
            'message' => 'min:10']);

        $data = array(
            'email' => $request->email,
            'name' => $request->subject,
            'message' => $request->message
        );

       

        Session::flash('success', 'Message sent successfully!');

        return redirect('pages.contact');
    }
}

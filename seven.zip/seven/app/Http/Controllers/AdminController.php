<?php

namespace SevenTecGroup\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use SevenTecGroup\User;
use SevenTecGroup\Blog;
use View;
use Auth;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    //view all posts
    public function allposts()
    {
        $posts = Post::all();
        return View::make("admin/allposts")->with("allPosts", $posts);
    }
    
    //view a single post
    public function adminviewpost(Request $request, $id)
    {
       $vpost = Post::find($id);
       return View::make("admin/viewpost")->with('vpost', $vpost);
    }
    
    //show add post form
    public function addpost()
    {
        $categories = Category::all(['name']);
        $tags = Tag::all(['name']);
	    return View::make('admin/addpost', compact('categories','tags'));
    }

    //save post to database
    public function poststore(Request $request)
    {
        $formInput=$request->except('image');
        
        //form validation
        $this->validate($request,[
           'title'=>'required',
           'body'=>'required',
        ]);

        Post::create($formInput);
        Session::flash('flash_message', 'Post added successfully!');
        return redirect()->route('allposts');
    }
    //show post edit form
     public function editpost(Request $request, $id)
    {
     $epost = Post::find($id);
     return View::make('admin/editpost', compact('categories','tags'))->with('editpost', $epost);
    }

    //update a post in a database
    public function admineditpostsave(Request $request, $id)
    {
        $epost = Post::find($id);
        $formInput=$request->except('image');
        //validation
        $this->validate($request,[
           'title'=>'required',
           'body'=>'required',
        ]);

        

        $epost->update($formInput);
        Session::flash('flash_message', 'Post updated successfully!');
        return redirect()->route('adminviewpost', $id);
    
  }
    //delete a post from database
    public function admindestroy(Request $request)
    {
        Post::find(Input::get('id'))->delete();
        Session::flash('flash_message', 'Post deleted successfully!');
        return redirect()->route('allposts');
    }  
}

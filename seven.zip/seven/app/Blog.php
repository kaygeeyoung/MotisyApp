<?php

namespace SevenTecGroup;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    
      protected $fillable=['id','title','tag','body','updated_at','created_at'];

}
